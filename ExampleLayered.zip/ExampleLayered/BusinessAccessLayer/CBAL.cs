﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using System.Text.RegularExpressions;
using DataAccessLayer;
using ExceptionLayer;

namespace BusinessAccessLayer
{
    public class CBAL
    {
        public bool Validations(CEntity entobj)
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();
            if((entobj.LOCATION.Equals(string.Empty)))
            {
                isValid = false;
                sb.AppendLine("Location cannot be empty.");
            }
            if(!Regex.IsMatch(entobj.SKILL,@"DotNet|Java|Testing"))
            {
                isValid = false;
                sb.AppendLine("Skills can either be DotNet, Java or Testing");
            }
            if(entobj.DAYS<0 || entobj.DAYS>50)
            {
                isValid = false;
                sb.AppendLine("Days should be greater than 0 and less than 50");
            }
            if(DateTime.Now < entobj.STARTDATE)
            {
                isValid = false;
                sb.AppendLine("Starting date should be less than today");
            }
            if (entobj.ENDDATE < entobj.STARTDATE )
            {
                isValid = false;
                sb.AppendLine("End date should be greater than starting date");
            }
            if (isValid == false)
            {
                Console.WriteLine(sb.ToString());
            }
            return isValid;
        }
        public bool addStudent(CEntity entobj)
        {
            bool result = false;
            if (Validations(entobj))
            {
                CDAL dalobj = new CDAL();
                dalobj.mAddStudent(entobj);
                result = true;
            }
            return result;
        }
        public List<CEntity> mDisplayStudents()
        {
            CDAL dalobj = new CDAL();
            return dalobj.mDisplayStudents();
        }
        public CEntity mSearchStudent(int trainingid)
        {
            try
            {
                CBAL balobj = new CBAL();
                return balobj.mSearchStudent(trainingid);
            }
            catch(Exception e)
            {
                throw e.;
            }
        }
    }
}
