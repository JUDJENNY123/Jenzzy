﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class CEntity
    {
        #region fields
        string _location;
        static int _statictrainingID;
        int _trainingID;
        string _skill;
        int _days;
        DateTime _startDate;
        DateTime _endDate;
        #endregion

        #region Property
        public string LOCATION
        {
            get { return _location; }
            set { _location = value; }
        }
        public int TRAININGID
        {
            get { return _trainingID; }
            set { _trainingID = value; }
        }
        public string SKILL
        {
            get { return _skill; }
            set { _skill = value; }
        }
        public int DAYS
        {
            get { return _days; }
            set { _days = value; }
        }
        public DateTime STARTDATE
        {
            get { return _startDate; }
            set { _startDate = value; }
        }
        public DateTime ENDDATE
        {
            get { return _endDate; }
            set { _endDate = value; }
        }
        #endregion
        #region Constructor
        public CEntity()
        {
            _statictrainingID = _statictrainingID + 1;
            _trainingID = _statictrainingID;
        }
        #endregion
    }
}
