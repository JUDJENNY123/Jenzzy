﻿using System;

namespace EmpUtility
{
    public interface IAttribute
    {
        string Message { get; set; }

        bool IsValid(object item);
    }
}
