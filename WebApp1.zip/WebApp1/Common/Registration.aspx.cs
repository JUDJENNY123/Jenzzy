﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entities;
using Exceptions;
using BAL;
namespace WebApp1
{
    public partial class Registration : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                RoomEntity newProj = new RoomEntity();

                newProj.CustomerName = TextBox1.Text;
                newProj.Address = TextBox2.Text;
                newProj.IdDoc = DropDownList3.SelectedItem.Value;
                newProj.HotelId = Convert.ToInt32(DropDownList2.SelectedItem.Value);
                newProj.DateIn =Convert.ToDateTime(TextBox3.Text);
                newProj.DateOut = Convert.ToDateTime(TextBox4.Text);
                newProj.RoomType =DropDownList4.SelectedItem.Value;
                //cost = Convert.ToDouble(newProj.DateOut.Day - newProj.DateIn.Day) * Convert.ToDouble(DropDownList4.SelectedItem.Value);
                newProj.cost = Convert.ToDouble(DropDownList4.SelectedItem.Value);
                double Amount = RoomBAL.getPrice(newProj);
                Label13.Text = "Price is:" + Amount.ToString();
                bool projAdded = RoomBAL.Addstud(newProj);

                if (projAdded)
                {
                    Label12.Text = "Customer Added";
                   // Label13.Text = "Price is:" + cost.ToString();
                }


                else
                    Label12.Text = "Customer not Added";



            }
            catch (Exception ex)
            {
                Label12.Text = ex.ToString();
            }
        }
    }
}