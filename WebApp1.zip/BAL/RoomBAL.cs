﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Exceptions;
using DAL;


namespace BAL
{
    public class RoomBAL
    {

        public static bool Addstud(RoomEntity newproj)
        {
            bool projAdded = false;
            try
            {

                RoomDAL proj = new RoomDAL();
                projAdded = proj.addproj(newproj);

            }
            catch (RoomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return projAdded;
        }
        public static double getPrice(RoomEntity cust)
        {
            double bill = Convert.ToDouble((cust.DateOut - cust.DateIn).TotalDays) * Convert.ToDouble(cust.cost);
            return bill;
        }
    }
}
