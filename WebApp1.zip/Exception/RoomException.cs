﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    public class RoomException:ApplicationException
    {
        public RoomException()
            : base()
        {
        }

        public RoomException(string message)
            : base(message)
        {
        }
        public RoomException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

    }
}
