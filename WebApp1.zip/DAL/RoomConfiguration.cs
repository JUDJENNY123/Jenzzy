﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Configuration;


namespace DAL
{
    class RoomConfiguration
    {
        private static string providername;

        public static string providerName
        {
            get { return RoomConfiguration.providername; }
            set { RoomConfiguration.providername = value; }
        }
        private static string connectionstring;
        public static string connectionString
        {
            get { return RoomConfiguration.connectionstring; }
            set { RoomConfiguration.connectionstring = value; }
        }

        // use of constructor
        static RoomConfiguration()
        {
            //defined in constructor
            // y only field name but property , meaning of this sentence

            providername = ConfigurationManager.ConnectionStrings["projectConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["projectConnection"].ConnectionString;
        }

    }
}
