﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Exceptions;
using System.Data;
using System.Data.Common;

namespace DAL
{
    public class RoomDAL
    {
        public bool addproj(RoomEntity newproj)
        {
            bool addguest = false;
            try
            {
                // how to relate dis with dataconnection layer
                DbCommand command = DataConnection.createCommand();
                command.CommandText = "Addcust";

                DbParameter param = command.CreateParameter();


                param = command.CreateParameter();
                param.ParameterName = "@CustomerName";
                param.DbType = DbType.String;
                param.Value = newproj.CustomerName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Address";
                param.DbType = DbType.String;
                param.Value = newproj.Address;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@IdDoc";
                param.DbType = DbType.String;
                param.Value = newproj.IdDoc;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@hotelId";
                param.DbType = DbType.Int32;
                param.Value = newproj.HotelId;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@DateIn";
                param.DbType = DbType.Date;
                param.Value = newproj.DateIn.Date;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@DateOut";
                param.DbType = DbType.Date;
                param.Value = newproj.DateOut.Date;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@RoomType";
                param.DbType = DbType.String;
                param.Value = newproj.RoomType;
                command.Parameters.Add(param);




                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    addguest = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.ToString() + ex.Message;
                        break;
                }
                throw new RoomException(errormessage);
            }
            return addguest;
        }
    }
}
