﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericstackClass
{
    class Emp:IComparable<Emp>
    {
        public string ENAME { get; set; }
        public int SALARY { get; set; }

        public int CompareTo(Emp other)
        {
            if (this.SALARY > other.SALARY)
                return 1;
            else if (this.SALARY < other.SALARY)
                return -1;
            else
                return 0; 
        }
    }
    public class MyStack<T> : Stack<T>
    { }
    class Program
    {
        static void Main(string[] args)
        {
            List<Emp> emps =
                new List<Emp>()
                {
                    new Emp {ENAME="E1",SALARY=18900},
                    new Emp {ENAME="E2",SALARY=17800},
                    new Emp {ENAME="E3",SALARY=19800}
                };
            emps.Sort();
            foreach (Emp e in emps)
            {
                Console.WriteLine(e.ENAME+" "+e.SALARY);
            }
           
            MyStack<string> cities = new MyStack<string>();
            cities.Push("Delhi");
            cities.Push("Chennai");
            cities.Push("Mumbai");
            cities.Push("Bangalore");
            cities.Push("Kolkata");
            foreach (string s in cities)
            {
                Console.WriteLine(s);
            }
            Console.WriteLine(cities.Contains("Mumbai"));
            Console.WriteLine(cities.Count);
            Console.ReadLine();

        }
    }
}
