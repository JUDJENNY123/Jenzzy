﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using MyMathLib;

namespace ConsoleApplication2
{
    delegate int mathdelegate(params int[] array);
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    class AuthorAttribute : Attribute
    {
        string _author;
        public AuthorAttribute(string author)
        {
            _author = author;
        }
        public string AuthorName
        {
            get
            {
                return _author;
            }
        }
    }
    enum Gender { Male,Female}
    [Author("Deepu")]
    [Author("Deepu")]
    class Student
    {
        public Gender gender { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            MyMath obj = new MyMath();
            Console.WriteLine(obj.DoSum(4,5,6,7,8));
            // using Delegate
            mathdelegate del = obj.DoSum;
            
            Console.WriteLine(del(4, 5, 6, 7, 8));


            Type type = typeof(Student);
            Console.WriteLine(type.IsAbstract);
            Console.WriteLine(type.IsClass);
            PropertyInfo[] pi = type.GetProperties();
            object[] attributes =
                type.GetCustomAttributes(typeof(AuthorAttribute), false);
            foreach (object o in attributes)
            {
                Console.WriteLine(((AuthorAttribute)o).AuthorName);
            }

            Console.ReadLine();
        }
    }
}
