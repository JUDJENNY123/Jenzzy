﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MyMathLib
{
    public class MyMath
    {
        public int DoSum(params int[] numarray)
        {
            int sum = 0;
            foreach (int item in numarray)
            {
                sum += item;
            }
            return sum;
        }
        public int DoMult(params int[] numarray)
        {
            int mult = 1;
            foreach (int item in numarray)
            {
                mult *= item;
            }
            return mult;
        }
    }

}
