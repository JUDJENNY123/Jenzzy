﻿namespace StudentList
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Runtime.Serialization.Formatters.Binary;
    using System.IO;
    using System.Runtime.Serialization;

    
   
    enum Gender { Male, Female }

    [Serializable]
    class Student 
    {
    

        #region Fields
        //int _studentID;
        //string _studentName;
        //int _standard;
        //string _gender;
        #endregion
        #region Methods

        #endregion
        #region Property
        public int STUDENTID { get ;  set;  }
        public string STUDENTNAME { get  ;  set ;  }
        public int STANDARD { get; set ; }
        public Gender GENDER { get ; set ; }
        #endregion
        #region constructor
        public Student()
        {

        }
        #endregion
    
        static void Main(string[] args)
        {
            List<Student> students =
                new List<Student>()
                {
                    new Student {STUDENTID=1,STUDENTNAME="S1",GENDER=Gender.Male,STANDARD=11 },
                    new Student {STUDENTID=2,STUDENTNAME="S2",GENDER=Gender.Female,STANDARD=6 },
                    new Student {STUDENTID=3,STUDENTNAME="S3",GENDER=Gender.Male,STANDARD=8 },
                    new Student {STUDENTID=4,STUDENTNAME="S4",GENDER=Gender.Male,STANDARD=12 }
                };
            Dictionary<Gender, double> percentages
                = new Dictionary<Gender, double>();
            double countmale = 0.0; double countfemale = 0.0;
            double permale = 0.0, perfemale = 0.0;
            foreach (Student s in students)
            {
                if (s.GENDER == Gender.Male)
                    countmale++;
                else
                       countfemale++;
            }
            permale = countmale / students.Count * 100;
            perfemale = countfemale / students.Count * 100;
            percentages.Add(Gender.Male, permale);
            percentages.Add(Gender.Female, perfemale);
            foreach (KeyValuePair<Gender,double> kv in percentages)
            {
                Console.WriteLine("Gender - {0} Percentage - {1}",kv.Key,kv.Value);
            }


            FileStream fileStream = new FileStream(@"d:\\ser.txt", FileMode.Create);
            BinaryFormatter binarywriter = new BinaryFormatter();
            //binarywriter.Serialize(fileStream, DateTime.Now);
            binarywriter.Serialize(fileStream, students);
            fileStream.Flush();
            fileStream.Close();
        
            fileStream  = new FileStream(@"d:\\ser.txt", FileMode.Open);
            List<Student> list = (List<Student>)binarywriter.Deserialize(fileStream);
           
             fileStream.Close();
            
            foreach (Student item in list)
            {
                Console.WriteLine(item.STUDENTID);
                Console.WriteLine(item.STUDENTNAME);
                Console.WriteLine(item.GENDER);
                Console.WriteLine(item.STANDARD);
            }

        }
    }
}
