﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Data;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using IGATEPATNI.GuestPhoneBook.BL;
using IGATEPATNI.GuestPhoneBook.Entities;
using IGATEPATNI.GuestPhoneBook.Exceptions;

namespace GuestDetails
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public object searchGuestID;

        //string sqlConnectString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Module 3\ADO.NET 4.5\Demos\ADO.NET DEMOS\Day3 - Demo On DAL\GuestPhoneBook\IGATEPATNI.DEMOS.ConsolePL\Database\Guest.mdf;Integrated Security=True";
        //SqlConnection conGuest;
        //SqlCommand comGuest;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            List<Guest> guestList = GuestBL.GetAllGuestsBL();
            dataGrid.ItemsSource = guestList;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int searchGuestID = Convert.ToInt32(GuestID.Text);
                Guest searchGuest = GuestBL.SearchGuestBL(searchGuestID);
                //if (searchGuest != null)
                //{
                //    searchGuest.GuestName = GuestName.Text;
                //    searchGuest.GuestContactNumber = GuestContact.Text;
                //    label.Content = "Guest Details Available";
                //}
                //else
                //{

                //    label.Content="No Guest Details Available";
                //}

                if (searchGuest != null)
                {

                    GuestName.Text = searchGuest.GuestName;
                    GuestContact.Text = searchGuest.GuestContactNumber;
                    label.Content = "Guest details available";
                }
                else
                    label.Content = "No guests available";

            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void dataGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {

            Guest gObj = (Guest)(object)dataGrid.SelectedItem;
            GuestID.Text = gObj.GuestID.ToString();
            GuestName.Text = gObj.GuestName;
            GuestContact.Text = gObj.GuestContactNumber;
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                int updateGuestID = Convert.ToInt32(GuestID.Text);
                Guest updatedGuest = GuestBL.SearchGuestBL(updateGuestID);
                if (updatedGuest != null)
                {
     
                    updatedGuest.GuestName = GuestName.Text;
                  
                    updatedGuest.GuestContactNumber = GuestContact.Text;
                    bool guestUpdated = GuestBL.UpdateGuestBL(updatedGuest);
                    if (guestUpdated)
                       label.Content="Guest Details Updated";
                    else
                       label.Content="Guest Details not Updated";
                }

            }
            catch (GuestPhoneBookException ex)
            {
              MessageBox.Show(ex.Message);
            }
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int deleteGuestID=Convert.ToInt32(GuestID.Text);
                Guest deleteGuest = GuestBL.SearchGuestBL(deleteGuestID);
                if (deleteGuest != null)
                {
                    bool guestdeleted = GuestBL.DeleteGuestBL(deleteGuestID);
                    if (guestdeleted)
                       label.Content="Guest Deleted";
                    else
                      label.Content=("Guest not Deleted ");
                }
                else
                {
                   label.Content=("No Guest Details Available");
                }


            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Guest gobj = new Guest();
                gobj.GuestID = Convert.ToInt32(GuestID.Text);
                gobj.GuestName = GuestName.Text;
                gobj.GuestContactNumber = GuestContact.Text;

                GuestBL.AddGuestBL(gobj);
                MessageBox.Show("Sucessfully added");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
