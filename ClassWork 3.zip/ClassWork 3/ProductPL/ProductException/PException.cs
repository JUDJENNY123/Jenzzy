﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductException
{
    public class PException:ApplicationException
    {
        //Default Constructor
        public PException()
        {
        }

        //Parameterized Constructor taking one string parameter
        public PException(string message) : base(message)
        {
        }

        //Parameterized Constructor taking two string parameters
        public PException(string message, Exception innerException) : base(message, innerException)
        {
        }

    }
}

