﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductBAL;
using ProductDAL;
using ProductException;
using ProductEntity;

namespace ProductPL
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int choice = 0;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter your choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddProduct();
                            break;

                        case 2:
                            DisplayProduct();
                            break;

                        case 3:
                            SearchProduct();
                            break;
                        case 4:
                            return;
                        default:
                            Console.WriteLine("Invalid choice.Please try again");
                            break;
                    }
                } while (choice != 3);
            }
            catch (FormatException ex)
            {

                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {

                Console.WriteLine(ex.Message);
            }
        }

        static void PrintMenu()
        {
            Console.WriteLine("-------------------------------------------------------------------------");
            Console.WriteLine("\n1.Add Product");
            Console.WriteLine("\n2.Display Products");
            Console.WriteLine("\n3.Search Product");
            Console.WriteLine("\n4.Exit\n");
            Console.WriteLine("--------------------------------------------------------------------------\n");
        }

        static void AddProduct()
        {
            try
            {
                // Create object of Entity class
                

                // store all product information
                //Console.WriteLine("Enter Product ID : ");
                //pobj.PRODUCTID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Product Name : ");
                string name = Console.ReadLine();
                Console.WriteLine("Enter product Quantity");
                int quan =Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter product Unit Price");
                decimal pr = Convert.ToDecimal(Console.ReadLine());

                PEnt pobj = new PEnt(name,quan,pr);
                // create object of business layer

                PBal pbl = new PBal();
                bool result = pbl.AddProduct(pobj);

                if(result)
                {
                    Console.WriteLine("\nProduct Added Successfully");
                }
            }
            catch(PException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        // Method to display Product

        static void DisplayProduct()
        {
            try
            {
                PBal pbl = new PBal();
                List<PEnt> list = pbl.DisplayProduct();
                Console.WriteLine("\n\n\t\t Details for all Products are: \n\n");
                foreach (PEnt item in list)
                {

                    Console.WriteLine("Product ID : {0}\nProduct Name: {1} \nProduct Quantity : {2}\nProduct Unit Price : {3}",
                                    item.PRODUCTID, item.PRODUCTNAME, item.QUANTITY, item.UNITPRICE);

                }
                Console.WriteLine();

            }
            catch (SystemException ex)
            {

                Console.WriteLine(ex.Message);
            }
        }

        //Method to search Product

        static void SearchProduct()
        {
            try
            {
                Console.WriteLine("Enter Product Id");
                int productID = Convert.ToInt32(Console.ReadLine());

                PBal pbl = new PBal();
                List<PEnt> productlist = new List<PEnt>(pbl.SearchProduct(productID));

                if (productlist.Count > 0)
                {
                    Console.WriteLine("\n\n\t\t Product with {0} productID is:\n\n", productID);
                    foreach (PEnt item in productlist)
                    {
                        Console.WriteLine("Product ID : {0}\nProduct Name: {1} \nProduct Quantity : {2}\nProduct Unit Price : {3}",
                                  item.PRODUCTID, item.PRODUCTNAME, item.QUANTITY, item.UNITPRICE);
                    }
                }
                else
                {
                    Console.WriteLine("No such Product found.");
                }
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
