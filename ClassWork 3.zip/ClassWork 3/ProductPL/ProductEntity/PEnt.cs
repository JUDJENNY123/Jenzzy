﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductEntity
{

    public class PEnt
    {
        static int id = 1;
        #region Fields
         int _productID;
        //int _productid;
        string _productName;
        int _quantity;
        decimal _unitPrice;
        #endregion
        #region Property
        public int PRODUCTID { get {return _productID; } set {_productID=value; } }
        public string PRODUCTNAME { get { return _productName; } set { _productName = value; } }
        public int QUANTITY { get { return _quantity; } set { _quantity = value; } }
        public decimal UNITPRICE { get { return _unitPrice; } set { _unitPrice = value; } }
        #endregion
        #region Methods

        #endregion
        #region Constructor
        public PEnt(string name,int quantity,decimal price)
        {
            PRODUCTID = id++;
            PRODUCTNAME = name;
            QUANTITY = quantity;
            UNITPRICE = price;
        }
        #endregion
    }
}
