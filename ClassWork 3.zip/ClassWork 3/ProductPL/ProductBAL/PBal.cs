﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductDAL;
using ProductEntity;
using ProductException;

namespace ProductBAL
{
    public class PBal
    {
        // Add Validation

        public bool ValidateProduct(PEnt pobj)
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();
            if(pobj.QUANTITY < 0)
            {
                isValid = false;
                sb.Append("Product quantity should be greater than 0");
            }
            
            if(isValid==false)
            {
                Console.WriteLine("\nErrors is/are :");
                Console.WriteLine(sb.ToString());
            }
            return isValid;
        }

        // method to add new Product

        public bool AddProduct(PEnt pobj)
        {
            bool result = false;
            //checking if the product object is valid
            if (ValidateProduct(pobj))
            {
                //Creating DAL class object
                PDal pro = new PDal();

                //Invoking its AddProduct method
                return pro.AddProduct(pobj);
            }
            return result;
        }

        // Method to display Product

        public List<PEnt> DisplayProduct()
        {
            PDal pdal = new PDal();
            return pdal.DisplayProduct();
        }


        // Method to search Product
        public List<PEnt> SearchProduct(int productId)
        {
            PDal pro = new PDal();
            return pro.SearchProduct(productId);
        }
    }
}
