﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductEntity;
using ProductException;
namespace ProductDAL
{
    public class PDal
    {
        public static List<PEnt> productList = new List<PEnt>();

        //Method to add new Product
        public bool AddProduct(PEnt pobj)
        {
            bool result = false;
            try
            {
                productList.Add(pobj);
                result = true;
            }
            catch (PException)
            {
                throw;
            }
            return result;
        }

        //Method to display all the Products
        public List<PEnt> DisplayProduct()
        {
            return productList;
        }

        //Method to search Product
        public List<PEnt> SearchProduct(int productId)
        {
            // Customer cobj = null;
            List<PEnt> newlist = new List<PEnt>();
            foreach (PEnt item in productList)
            {
                if (item.PRODUCTID == productId)
                {
                    newlist.Add(item);
                }
            }
            return newlist;
        }

        //Serialization of Data 
        //private static void SerializeData(List<Customer> e)
        //{
        //    FileStream fileStream = new FileStream("d:\\ser.dat", FileMode.Create);
        //    BinaryFormatter binaryFormatter = new BinaryFormatter();
        //    foreach (Customer item in e)
        //    {
        //        binaryFormatter.Serialize(fileStream, item);
        //    }
        //    fileStream.Close();
        //}

        ////Deserialization of Data
        //public static ICollection<Student> DeserializeList<Student>(FileStream fs)
        //{
        //    BinaryFormatter bf = new BinaryFormatter();
        //    List<Student> list = new List<Student>();
        //    while (fs.Position != fs.Length)
        //    {
        //        //deserialize each object in the file
        //        var deserialized = (Student)bf.Deserialize(fs);
        //        //add individual object to a list
        //        list.Add(deserialized);
        //    }
        //    //return the list of objects
        //    return list;
        //}
    }
}
