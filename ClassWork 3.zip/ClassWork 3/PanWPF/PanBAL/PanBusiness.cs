﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PanDL;
using PanEntities;
using PanExceptions;
namespace PanBAL
{
    public class PanBusiness
    {

        private static bool ValidatePan(PANEntities pan)
        {
            StringBuilder sb = new StringBuilder();
            bool validPan = true;
            if (pan.PAN_No <= 0)
            {
                validPan = false;
                sb.Append(Environment.NewLine + "Invalid PAN ID");

            }
            if (pan.Person_Name == string.Empty)
            {
                validPan = false;
                sb.Append(Environment.NewLine + "Person Name Required");

            }
            if (pan.City == string.Empty)
            {
                validPan = false;
                sb.Append(Environment.NewLine + "City Name Required");
            }

            if (pan.Address == string.Empty)
            {
                validPan = false;
                sb.Append(Environment.NewLine + "Address Required");
            }

            if (pan.date_Of_Creation.Equals( string.Empty))
            {
                validPan = false;
                sb.Append(Environment.NewLine + "Date Required");
            }
            if (validPan == false)
                throw new PanException(sb.ToString());
            return validPan;
        }


        public static bool AddPan(PANEntities pan)
        {
            bool panAdded = false;
            try
            {
                if (ValidateGuest(pan))
                {
                   PanDAL panDAL = new PanDAL();
                    panAdded = panDAL.AddPanDAL(pan);
                }
            }
            catch (PanException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return panAdded;
        }

        public static List<PANEntities> GetAllPANBL()
        {
            List<PANEntities> guestList = null;
            try
            {
                PanDAL panDAL = new PanDAL();
                guestList = panDAL.GetAllPanDAL();
            }
            catch (PanException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return guestList;
        }

        public static PANEntities SearchPanBL(int searchpanID)
        {
            PANEntities searchPan = null;
            try
            {
                PanDAL panDAL = new PanDAL();
                searchPan = panDAL.SearchPanDAL(searchpanID);
            }
            catch (PanException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPan;

        }

        public static bool UpdateGuestBL(PANEntities updatePan)
        {
            bool panUpdated = false;
            try
            {
                if (ValidatePan(updatePan))
                {
                    PanDAL guestDAL = new PanDAL();
                    panUpdated = guestDAL.UpdatePanDAL(updatePan);
                }
            }
            catch (PanException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return panUpdated;
        }

        public static bool DeletePanBL(int deletePanID)
        {
            bool guestDeleted = false;
            try
            {
                if (deletePanID > 0)
                {
                    PanDAL guestDAL = new PanDAL();
                    guestDeleted = guestDAL.DeletePanDAL(deletePanID);
                }
                else
                {
                    throw new PanException("Invalid Pan ID");
                }
            }
            catch (PanException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return guestDeleted;
        }
    }
}

