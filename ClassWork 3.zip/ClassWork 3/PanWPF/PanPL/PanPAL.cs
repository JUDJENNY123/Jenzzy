﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PanBAL;
using PanEntities;
using PanExceptions;
namespace PanPL
{
    public class PanPAL
    {
    }
}
