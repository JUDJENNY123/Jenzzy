﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class BEntities
    {
        public int CustID { get; set; }

        public string CustName { get; set; }

        public string City { get; set; }

        public decimal PIN { get; set; }

        public DateTime DateOfReg { get; set; }
    }
}
