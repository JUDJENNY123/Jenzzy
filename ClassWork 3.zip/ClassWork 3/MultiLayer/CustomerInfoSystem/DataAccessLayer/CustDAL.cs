﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using Entities;
using Exceptions;

namespace DataAccessLayer
{
    public class CustDAL
    {
        

        public bool AddCust(BEntities newCust)
        {
            bool custAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "AddCust";

                DbParameter param1 = command.CreateParameter();
                param1.ParameterName = "@custid";
                param1.DbType = DbType.Int64;
                param1.Direction = ParameterDirection.Output;
                command.Parameters.Add(param1);

                param1 = command.CreateParameter();
                param1.ParameterName = "@custname";
                param1.DbType = DbType.String;
                param1.Value = newCust.CustName;
                command.Parameters.Add(param1);

                param1 = command.CreateParameter();
                param1.ParameterName = "@city";
                param1.DbType = DbType.String;
                param1.Value = newCust.City;
                command.Parameters.Add(param1);

                param1 = command.CreateParameter();
                param1.ParameterName = "@pin";
                param1.DbType = DbType.Decimal;
                param1.Value = newCust.PIN;
                command.Parameters.Add(param1);

                param1 = command.CreateParameter();
                param1.ParameterName = "@dor";
                param1.DbType = DbType.Date;
                param1.Value = newCust.DateOfReg.Date;
                command.Parameters.Add(param1);

                int rowsaffected = DataConnection.ExecuteNonQueryCommand(command);
                if (rowsaffected > 0)
                {
                    custAdded = true;
                }
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new CustException(errormessage);
            }
            return custAdded;
        }

        public bool DeleteCust(int CustID)
        {
            bool custdel = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "DeleteCust";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@custid";
                param.DbType = DbType.Int32;
                param.Value = CustID;
                command.Parameters.Add(param);

                int rowsaffected = DataConnection.ExecuteNonQueryCommand(command);
                if (rowsaffected > 0)
                {
                    custdel = true;
                }
            }
            catch (DbException ex)
            {
                throw new CustException(ex.Message);
            }
            return custdel;
        }
        public BEntities SearchCust(int CustID)
        {
            BEntities searchcust = null;
            try
            {
                
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "SearchCust";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@custid";
                param.DbType = DbType.Int32;
                param.Value = CustID;
                command.Parameters.Add(param);

                DataTable dt = DataConnection.ExecuteSelectCommand(command);
                if (dt.Rows.Count > 0)
                {
                    searchcust = new BEntities();
                    searchcust.CustID = (int)dt.Rows[0][0];
                    searchcust.CustName = (string)dt.Rows[0][1];
                    searchcust.City = (string)dt.Rows[0][2];
                    searchcust.PIN = (decimal)dt.Rows[0][3];
                    searchcust.DateOfReg = (DateTime)dt.Rows[0][4];
                }
            }
            catch (DbException ex)
            {
                throw new CustException(ex.Message);
            }
            return searchcust;
        }

        public List<BEntities> ShowAll()
        {
            List<BEntities> all = null;
            DbCommand command = DataConnection.CreateCommand();
            command.CommandText = "ShowAll";
            try
            {
                DataTable dt = DataConnection.ExecuteSelectCommand(command);
                if (dt.Rows.Count > 0)
                {
                    all = new List<BEntities>();
                    for (int rowcount = 0; rowcount < dt.Rows.Count; rowcount++)
                    {
                        BEntities cust = new BEntities();
                        cust.CustID = (int)dt.Rows[rowcount][0];
                        cust.CustName = (string)dt.Rows[rowcount][1];
                        cust.City = (string)dt.Rows[rowcount][2];
                        cust.PIN = (decimal)dt.Rows[rowcount][3];
                        cust.DateOfReg = (DateTime)dt.Rows[rowcount][4];
                        all.Add(cust);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new CustException(ex.Message);
            }
            return all;
        }

        public bool UpdateCust(BEntities newCust)
        {
            bool custUpdated = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "UpdateCust";

                DbParameter param1 = command.CreateParameter();
                param1.ParameterName = "@custid";
                param1.DbType = DbType.Int64;
                param1.Value = newCust.CustID;
                command.Parameters.Add(param1);

                param1 = command.CreateParameter();
                param1.ParameterName = "@custname";
                param1.DbType = DbType.String;
                param1.Value = newCust.CustName;
                command.Parameters.Add(param1);

                param1 = command.CreateParameter();
                param1.ParameterName = "@city";
                param1.DbType = DbType.String;
                param1.Value = newCust.City;
                command.Parameters.Add(param1);

                param1 = command.CreateParameter();
                param1.ParameterName = "@pin";
                param1.DbType = DbType.Decimal;
                param1.Value = newCust.PIN;
                command.Parameters.Add(param1);

                param1 = command.CreateParameter();
                param1.ParameterName = "@dor";
                param1.DbType = DbType.Date;
                param1.Value = newCust.DateOfReg.Date;
                command.Parameters.Add(param1);

                int rowsaffected = DataConnection.ExecuteNonQueryCommand(command);
                if (rowsaffected > 0)
                {
                    custUpdated = true;
                }
            }
            catch (DbException ex)
            {
                throw new CustException(ex.Message);
            }
            return custUpdated;
        }
    }
}
