﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
namespace DataAccessLayer
{
    public class CustConfiguration
    {
        public static string providerName;
        public static string ProviderName 
        {
            get {return CustConfiguration.providerName ; }
            set {CustConfiguration.providerName=value ; }
        }
        public static string connectionString;
        public static string ConnectionString 
        {
            get {return CustConfiguration.connectionString ; }
            set {CustConfiguration.connectionString=value ; }
        }
        static CustConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["customerConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["customerConnection"].ConnectionString;
        }
    }
}
