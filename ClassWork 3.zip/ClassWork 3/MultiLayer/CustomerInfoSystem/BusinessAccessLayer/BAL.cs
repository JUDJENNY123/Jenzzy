﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exceptions;
using Entities;
using DataAccessLayer;

namespace BusinessAccessLayer
{
    public class BAL
    {
        public static bool Validations(BEntities customer)
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();
            if (customer.CustName.Length < 1)
            {
                isValid = false;
                sb.Append("Enter a valid name");
            }
            if ((!(customer.City.Equals("Mumbai")) && (!(customer.City.Equals("Bangalore")))))
            {
                isValid = false;
                sb.Append("City should be Mumbai or Bangalore");
            }
            
            string stPIN= customer.PIN.ToString();
            if(stPIN.Length<6)
            {
                sb.Append("PIN should be 6 digits in size");
            }
            
            if (customer.DateOfReg.Year < 2017)
            {
                sb.Append("Registration should be after 2017");
            }
            if (isValid == false)
                throw new CustException(sb.ToString());
            return isValid;
        }
        
        public bool AddCust(BEntities newCust)
        {
            bool CustAdded;
            try
            {
                if (Validations(newCust))
                {
                    CustDAL dal_cust = new CustDAL();

                    CustAdded = dal_cust.AddCust(newCust);
                }
                else
                {
                    CustAdded = false;
                }

            }
            catch (CustException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CustAdded;
        }
        
        public static bool DelCust(int CustID)
        {
            bool custdel;
            try
            {
                if (CustID > 0)
                {
                    CustDAL customer = new CustDAL();
                    custdel = customer.DeleteCust(CustID);
                }
                else
                {
                    custdel = false;
                    throw new CustException("Invalid Customer ID");
                }
            }
            catch (CustException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return custdel;
        }
        
        public static BEntities SearchCust(int CustID)
        {
            BEntities searchcust = null;
            try
            {
                if (CustID > 0)
                {
                    CustDAL customer = new CustDAL();
                    searchcust = customer.SearchCust(CustID);
                }
                else
                {
                    throw new CustException("Invalid Customer");
                }
            }
            catch (CustException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchcust;
        }

        public static List<BEntities> SearchAll()
        {
            List<BEntities> allcust = null;
            try
            {
                CustDAL dalobj = new CustDAL();
                allcust = dalobj.ShowAll();
            }
            catch (CustException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return allcust;
        }

        public static bool UpdateCust(BEntities cust)
        {
            bool custUpdated = false;
            try
            {
                if (Validations(cust))
                {
                    CustDAL custDAL = new CustDAL();
                    custUpdated = custDAL.UpdateCust(cust);
                }
            }
            catch (CustException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return custUpdated;
        }
    }
}
