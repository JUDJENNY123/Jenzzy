﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entities;
using Exceptions;
using BusinessAccessLayer;

namespace DisplayApp
{
    // <summary>
    // Interaction logic for MainWindow.xaml
    // </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BEntities cust = new BEntities();
                cust.CustName = txtName.Text;
                cust.City = txtCity.Text;
                cust.PIN = Convert.ToDecimal(txtPin.Text);
                cust.DateOfReg = Convert.ToDateTime(dp1.Text);
                BAL bal_cust = new BAL();
                bool custAdded = bal_cust.AddCust(cust);

                if (custAdded == true)
                {
                    lblShowOp.Content = "Customer Added";
                }
                else
                {
                    lblShowOp.Content = "Could not add";
                }
            }
            catch (CustException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int tobesearched = Convert.ToInt32(txtCid.Text);
                BEntities cust = BAL.SearchCust(tobesearched);
                txtName.Text = cust.CustName;
                txtCity.Text = cust.City;
                txtPin.Text = Convert.ToString(cust.PIN);
                dp1.Text = Convert.ToString(cust.DateOfReg);
                if (cust == null)
                {
                    lblShowOp.Content = "No such record found";
                }
            }
            catch (CustException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int tobedeleted = Convert.ToInt32(txtCid.Text);

                BEntities delobj = BAL.SearchCust(tobedeleted);
                if (delobj == null)
                {
                    lblShowOp.Content = "Cannot be deleted";
                }
                else
                {
                    BAL.DelCust(tobedeleted);
                    lblShowOp.Content = "Deleted";
                }
            }
            catch (CustException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnShowAll_Click(object sender, RoutedEventArgs e)
        {
            datagrid1.ItemsSource = BAL.SearchAll();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int CustID = Convert.ToInt32(txtCid.Text);

                BEntities updateCust = BAL.SearchCust(CustID);
                updateCust.CustName = txtName.Text;
                updateCust.City = txtCity.Text;
                updateCust.PIN = Convert.ToDecimal(txtPin.Text);
                updateCust.DateOfReg = Convert.ToDateTime(dp1.Text);

                bool custupdated = BAL.UpdateCust(updateCust);
                if (custupdated == true)
                {
                    lblShowOp.Content = "Updated";
                }
                else
                {
                    lblShowOp.Content = "Not Updated";
                }
            }
            catch(CustException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
