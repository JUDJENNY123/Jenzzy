﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data;
using PEntityLayer;
using PExceptionLayer;

namespace PDALayer
{
    public class PanDal
    {
        public bool AddPanDAL(PanEntites pan)
        {
            bool panAdded = false;
            try
            {
                DbCommand command = DataConnections.CreateCommand();
                command.CommandText = "AddPan";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@panNo";
                param.DbType = DbType.Int32;
                param.Value = pan.PANNO;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@personName";
                param.DbType = DbType.String;
                param.Value = pan.PERSONNAME;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@city";
                param.DbType = DbType.String;
                param.Value = pan.CITY;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@address";
                param.DbType = DbType.String;
                param.Value = pan.ADDRESS;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@date";
                param.DbType = DbType.Date;
                param.Value = pan.DATEOFCREATION;
                command.Parameters.Add(param);

                int affectedRows = DataConnections.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    panAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new PanException(errormessage);
            }
            return panAdded;

        }

        public List<PanEntites> ShowAllDAL()
        {
            List<PanEntites> panlist = null;
            try
            {
                DbCommand command = DataConnections.CreateCommand();
                command.CommandText = "GetAllPan";



                DataTable dataTable = DataConnections.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    panlist = new List<PanEntites>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        PanEntites panobj = new PanEntites();
                        panobj.PANNO = Convert.ToInt32(dataTable.Rows[rowCounter][0]);
                        panobj.PERSONNAME = (string)dataTable.Rows[rowCounter][1];
                        panobj.CITY = (string)dataTable.Rows[rowCounter][2];
                        panobj.ADDRESS = (string)dataTable.Rows[rowCounter][3];
                        panobj.DATEOFCREATION = Convert.ToDateTime(dataTable.Rows[rowCounter][4]);

                        panlist.Add(panobj);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new PanException(ex.Message);
            }
            return panlist;
        }

        public PanEntites SearchPanDAL(int panno)
        {
            PanEntites panobj = null;
            try
            {
                DbCommand command = DataConnections.CreateCommand();
                command.CommandText = "SearchPan";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@panNo";
                param.DbType = DbType.Int32;
                param.Value = panno;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnections.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    panobj = new PanEntites();
                    panobj.PANNO = Convert.ToInt32( dataTable.Rows[0][0]);
                    panobj.PERSONNAME = (string)dataTable.Rows[0][1];
                    panobj.CITY = (string)dataTable.Rows[0][2];
                    panobj.ADDRESS = (string)dataTable.Rows[0][3];
                    panobj.DATEOFCREATION = Convert.ToDateTime(dataTable.Rows[0][4]);

                }
            }
            catch (DbException ex)
            {
                throw new PanException(ex.Message);
            }
            return panobj;
        }

        public bool UpdatePanDAL(PanEntites updatePan)
        {
            bool panUpdated = false;
            try
            {
                DbCommand command = DataConnections.CreateCommand();
                command.CommandText = "UpdatePan";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@panNo";
                param.DbType = DbType.Int32;
                param.Value = updatePan.PANNO;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@personName";
                param.DbType = DbType.String;
                param.Value = updatePan.PERSONNAME;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@city";
                param.DbType = DbType.String;
                param.Value = updatePan.CITY;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@address";
                param.DbType = DbType.String;
                param.Value = updatePan.ADDRESS;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@date";
                param.DbType = DbType.DateTime;
                param.Value = updatePan.DATEOFCREATION;
                command.Parameters.Add(param);

                int affectedRows = DataConnections.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    panUpdated = true;
            }
            catch (DbException ex)
            {
                throw new PanException(ex.Message);
            }
            return panUpdated;

        }

        public bool DeletePanDAL(int deletePan)
        {
            bool guestDeleted = false;
            try
            {
                DbCommand command = DataConnections.CreateCommand();
                command.CommandText = "DeletePan";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@panNo";
                param.DbType = DbType.Int32;
                param.Value = deletePan;
                command.Parameters.Add(param);

                int affectedRows = DataConnections.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    guestDeleted = true;
            }
            catch (DbException ex)
            {
                throw new PanException(ex.Message);
            }
            return guestDeleted;

        }

    }
}

