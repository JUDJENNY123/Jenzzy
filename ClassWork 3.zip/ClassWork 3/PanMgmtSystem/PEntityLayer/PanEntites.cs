﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEntityLayer
{
    public class PanEntites
    {
        #region Fields
        public int PANNO { get; set; }
        public string PERSONNAME { get; set; }
        public string CITY { get; set; }
        public string ADDRESS { get; set; }
        public DateTime DATEOFCREATION { get; set; }
        #endregion

    }
}
