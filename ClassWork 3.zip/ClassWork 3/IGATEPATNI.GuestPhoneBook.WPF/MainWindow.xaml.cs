﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using IGATEPATNI.GuestPhoneBook.Entities;
using IGATEPATNI.GuestPhoneBook.BL;
using IGATEPATNI.GuestPhoneBook.Exceptions;

namespace IGATEPATNI.GuestPhoneBook.WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void btnGetAllGuest_Click(object sender, RoutedEventArgs e)
        {
            List<Guest> guestList = GuestBL.GetAllGuestsBL();
            dataGrid.ItemsSource = guestList;
        }
        private void btnAddGuest_Click(object sender, RoutedEventArgs e)
        {
            Guest newGuest = new Guest();
            newGuest.GuestID = Convert.ToInt32(textbox1.Text);
            newGuest.GuestName = textbox2.Text;
            newGuest.GuestContactNumber = textbox3.Text;
            bool guestAdded = GuestBL.AddGuestBL(newGuest);
            if (guestAdded)
                label1.Content="Guest Added";
            else
                MessageBox.Show("Guest not Added");
        }

        private void btnFind_Click(object sender, RoutedEventArgs e)
        {
            Guest searchGuest = GuestBL.SearchGuestBL(Convert.ToInt32(textbox1.Text));
            if (searchGuest != null)
            {
                textbox2.Text = searchGuest.GuestName;
                textbox3.Text = searchGuest.GuestContactNumber;
            }
            else
            {
                 label1.Content="No Guest Details Available";
            }
        }

        private void btnupdate_Click(object sender, RoutedEventArgs e)
        {
            Guest updatedGuest = GuestBL.SearchGuestBL(Convert.ToInt32(textbox1.Text));
            if (updatedGuest != null)
            {
                updatedGuest.GuestName = textbox2.Text;
                updatedGuest.GuestContactNumber = textbox3.Text;
                bool guestUpdated = GuestBL.UpdateGuestBL(updatedGuest);
                if (guestUpdated)
                    label1.Content="Guest Details Updated";
                else
                    label1.Content="Guest Details not Updated ";
            }
            else
            {
                label1.Content="No Guest Details Available";
            }
        }

        private void btndelete_Click(object sender, RoutedEventArgs e)
        {
            Guest deleteGuest = GuestBL.SearchGuestBL(Convert.ToInt32(textbox1.Text));
            if (deleteGuest != null)
            {
                bool guestdeleted = GuestBL.DeleteGuestBL(Convert.ToInt32(textbox1.Text));
                if (guestdeleted)
                    label1.Content="Guest Deleted";
                else
                    label1.Content="Guest not Deleted ";
            }
            else
            {
                label1.Content="No Guest Details Available";
            }

        }

        

    }
}
