﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PanException;
using ClassEntity;
using System.Data.Common;
using System.Data;

namespace PanManagementDAL
{
    public class DAL
    {
        public bool AddPAN(PanEntity newPAN)
        {
            bool PANAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "AddPANDetails";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@PAN_NO";
                param.DbType = DbType.Int32;
                param.Value = newPAN.PANNO;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@Name";
                param.DbType = DbType.String;
                param.Value = newPAN.Name;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@City";
                param.DbType = DbType.String;
                param.Value = newPAN.city;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Address";
                param.DbType = DbType.String;
                param.Value = newPAN.Address;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Date_of_Creation";
                param.DbType = DbType.DateTime;
                param.Value = newPAN.DateofCreation;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    PANAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new PANException(errormessage);
            }
            return PANAdded;

        }

        public List<PanEntity> GetAllPANDetailsDAL()
        {
            List<PanEntity> guestPAN = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspGetAllGuests";



                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    guestPAN = new List<PanEntity>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        PanEntity pan = new PanEntity();
                        pan.PANNO = (int)dataTable.Rows[rowCounter][0];
                        pan.Name = (string)dataTable.Rows[rowCounter][1];
                        pan.city = (string)dataTable.Rows[rowCounter][2];
                        pan.Address = (string)dataTable.Rows[rowCounter][3];
                        pan.DateofCreation = (DateTime)dataTable.Rows[rowCounter][4];
                        guestPAN.Add(pan);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new PANException(ex.Message);
            }
            return guestPAN;
        }

        public PanEntity DALSearchPAN(int searchPanID)
        {
            PanEntity searchPan = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "SearchPAN";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@PAN_NO";
                param.DbType = DbType.Int32;
                param.Value = searchPan;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchPan = new PanEntity();
                    searchPan.PANNO = (int)dataTable.Rows[0][0];
                    searchPan.Name = (string)dataTable.Rows[0][1];
                    searchPan.city = (string)dataTable.Rows[0][2];
                    searchPan.Address = (string)dataTable.Rows[0][3];
                    searchPan.DateofCreation = (DateTime)dataTable.Rows[0][4];

                }
            }
            catch (DbException ex)
            {
                throw new PANException(ex.Message);
            }
            return searchPan;
        }

        public bool UpdatePanDAL(PanEntity updatePan)
        {
            bool PanUpdated = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "updatePAN";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@PAN_NO";
                param.DbType = DbType.Int32;
                param.Value = updatePan.PANNO;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@Name";
                param.DbType = DbType.String;
                param.Value = updatePan.Name;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@City";
                param.DbType = DbType.String;
                param.Value = updatePan.city;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Address";
                param.DbType = DbType.String;
                param.Value = updatePan.Address;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Date_of_Creation";
                param.DbType = DbType.String;
                param.Value = updatePan.city;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    PanUpdated = true;
            }
            catch (DbException ex)
            {
                throw new PANException(ex.Message);
            }
            return PanUpdated;

        }

        public bool DeleteGuestDAL(int deletePANID)
        {
            bool PANDeleted = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "DeletePAN";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@PAN_NO";
                param.DbType = DbType.Int32;
                param.Value = deletePANID;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    PANDeleted = true;
            }
            catch (DbException ex)
            {
                throw new PANException(ex.Message);
            }
            return PANDeleted;

        }
    }
}
