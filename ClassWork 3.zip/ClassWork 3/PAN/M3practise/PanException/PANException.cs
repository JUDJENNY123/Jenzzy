﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PanException
{
    public class PANException:ApplicationException
    {
        public PANException()
            : base()
        {
        }

        public PANException(string message)
            : base(message)
        {
        }
        public PANException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

    }
}
