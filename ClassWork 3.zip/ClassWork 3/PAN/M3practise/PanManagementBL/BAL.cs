﻿using System;
using System.Collections.Generic;
using System.Text;
using ClassEntity;
using PanManagementDAL;
using PanException;

namespace PanManagementBL
{
    public class BAL
    {
        private static bool ValidatePAN(PanEntity pobj)
        {
            StringBuilder sb = new StringBuilder();
            bool validPAN = true;
            if (pobj.PANNO <= 0)
            {
                validPAN = false;
                sb.Append(Environment.NewLine + "Invalid PAN Number");

            }
            if (pobj.Name == string.Empty)
            {
                validPAN = false;
                sb.Append(Environment.NewLine + "Person Name Required");

            }
            if (pobj.city == string.Empty)
            {
                validPAN = false;
                sb.Append(Environment.NewLine + "City Name Required");

            }
            if (pobj.Address == string.Empty)
            {
                validPAN = false;
                sb.Append(Environment.NewLine + "City Name Required");

            }
            if (validPAN == false)
                throw new PANException(sb.ToString());
            return validPAN;
        }

        public static bool AddPANNo(PanEntity newPANNO)
        {
            bool PANAdded = false;
            try
            {
                if (ValidatePAN(newPANNO))
                {
                    DAL guestDAL = new DAL();
                    PANAdded = guestDAL.AddPAN(newPANNO);
                }
            }
            catch (PANException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return PANAdded;
        }

        public static List<PanEntity> GetAllPANDetailsDAL()
        {
            List<PanEntity> panList = null;
            try
            {
                DAL guestDAL = new DAL();
                panList = guestDAL.GetAllPANDetailsDAL();
            }
            catch (PANException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return panList;
        }

        public static PanEntity SearchPANBL(int searchPanID)
        {
            PanEntity searchPan = null;
            try
            {
                DAL PanDAL = new DAL();
                searchPan = PanDAL.DALSearchPAN( searchPanID);
            }
            catch (PANException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPan;

        }

        public static bool UpdatePANBL(PanEntity updatePAN)
        {
            bool panUpdated = false;
            try
            {
                if (ValidatePAN(updatePAN))
                {
                    DAL panDAL = new DAL();
                    panUpdated = panDAL.UpdatePanDAL(updatePAN);
                }
            }
            catch (PANException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return panUpdated;
        }

        public static bool DeletePanBL(int deletePanID)
        {
            bool PanDeleted = false;
            try
            {
                if (deletePanID > 0)
                {
                    DAL guestDAL = new DAL();
                    PanDeleted = guestDAL.DeleteGuestDAL(deletePanID);
                }
                else
                {
                    throw new PANException("Invalid Guest ID");
                }
            }
            catch (PANException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return PanDeleted;
        }
    }
}
    

