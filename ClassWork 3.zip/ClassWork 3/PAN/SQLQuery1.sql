create database PAN;
 use PAN;

 CREATE TABLE PAN (
    PANNO int identity(1000,1) primary key,
    Name varchar(20) ,
    City varchar(30),
	addressofPAN varchar(50),
	DateofCreation DateTime,
  
);

GO
CREATE PROCEDURE AddPANDetails 
	
	(
	@PAN_NO int,
	@Name varchar(25),
	@City varchar(15),
	@Address varchar(50),
	@Date_of_Creation DateTime

	)
	
AS
	insert into PAN(PANNO,Name,City,addressofPAN,DateofCreation) Values(@PAN_NO,@Name,@City,@Address,@Date_of_Creation)
	RETURN

GO
CREATE PROCEDURE DeletePAN 
	
	(
	@PAN_NO int
	
	)
	
AS
	Delete from PAN where PANNO = @PAN_NO;
	RETURN


	GO
	CREATE PROCEDURE updatePAN 
	(
	@PAN_NO int,
	@Name varchar(25),
	@City varchar(15),
	@Address varchar(50),
	@Date_of_Creation DateTime
	)
AS
	update PAN set PANNO = @PAN_NO,Name = @Name, City=@City, addressofPAN=@Address, DateofCreation=@Date_of_Creation     where PANNO = @PAN_NO;
	RETURN

	GO
	CREATE PROCEDURE SearchPAN 
	
	(
	@PAN_NO int
	
	)
	
AS
		select PANNO,Name,City,addressofPAN,DateofCreation from PAN where PANNO = @PAN_NO;
	RETURN


	GO
	CREATE PROCEDURE GetAllPANDetails 
    

AS
	select PANNO,Name,City,addressofPAN,DateofCreation from PAN;
	RETURN


