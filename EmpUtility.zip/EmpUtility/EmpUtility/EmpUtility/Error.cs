﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpUtility
{
    public class Error
    {
        #region Fields
        private string _message;
        private string _property;
        #endregion

        #region Property
        public string PROPERTY { get {return _property ; } set { _property = value; } }
        public string MESSAGE { get { return _message; } set { _message = value; } }
        #endregion
        #region Constructor
        public Error()
        {
            PROPERTY = string.Empty;
            MESSAGE = string.Empty;
        }

        public Error(string message , string property)
        {
            PROPERTY = message;
            MESSAGE = property;
        }
        #endregion
    }
}
