﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace EmpUtility
{
   public interface IAttribute
    {
        string Message { get; set; }

        bool isValid(object item);
    }
}
