﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpUtility;
using System.Reflection;

namespace EmployeeUI
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeeConditions employee = new EmployeeeConditions();
            Console.Write("Enter Employee ID:");
            employee.EmployeeID = Console.ReadLine();

            Console.Write("Enter Employee Name:");
            employee.EmployeeName = Console.ReadLine();

            Console.Write("Enter Employee DOB:");
            employee.EmployeeDOB = Console.ReadLine();

            if (!ValidateEmployee(employee))
            {
                foreach (Error error in employee.ERRORLIST)
                {
                    Console.WriteLine("{0}", error.MESSAGE);
                }
            }
            else
            {
                Console.WriteLine("Employee Id = {0} and Name = {1} and Age = {2}", employee.EmployeeID, employee.EmployeeName,employee.EmployeeDOB);
            }

            Console.ReadKey();
        }

        private static bool ValidateEmployee(EmployeeeConditions employee)
        {
            PropertyInfo[] properties = employee.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo property in properties)
            {
                object[] customAtt = property.GetCustomAttributes(typeof(IAttribute), true);

                foreach (object att in customAtt)
                {
                    IAttribute valAtt = (IAttribute)att;
                    if (valAtt == null) continue;

                    if (valAtt.isValid(property.GetValue(employee, null))) continue;
                    Error error = new Error(property.Name, valAtt.Message);
                    employee.ERRORLIST.Add(error);

                }

            }

            return (employee.ERRORLIST.Count == 0);

        }
    }
}
