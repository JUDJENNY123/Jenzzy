﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankClasslib
{
    class ValidateName
    {
        [AttributeUsage(AttributeTargets.Property | AttributeTargets.Method, AllowMultiple = true)]
        public class ValidateName1: Attribute
        {
            #region FIELD
            string _message;
            #endregion

            #region PROPERTY

            //public string MESSAGE{get{return _message;} set {_message=value;}
            public string MESSAGE { get { return _message; } set { _message = value; } }
            #endregion

            #region METHOD

            public bool IsValid(string name)
            {
                bool flag = false;
                string myname = name;
                if (myname.Equals(name.ToUpper()))
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
                return flag;

            }
            #endregion

            #region CONSTRUCTOR
            #endregion

        }


    }
}
