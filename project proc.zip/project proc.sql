GO
alter Procedure [dbo].[UpdateGrade]
	(
	@GradeID int,
	@GradeName char(1),
	@Description varchar(10),
	@MinMarks int,
	@MaxMarks int
	)
	AS
	update Grade 
	set GradeName = @GradeName,Description = @Description, MinMarks=@MinMarks, MaxMarks=@MaxMarks
	where GradeID=@GradeID
	RETURN


	GO
alter Procedure [dbo].[SearchGrade]
	(
	@GradeID int
	)
	AS
	select GradeID,GradeName,Description,MinMarks,MaxMarks from Grade where GradeID = @GradeID;
	RETURN

	
	go
	Create Procedure [dbo].[GetGrade]
AS
select GradeID,GradeName,Description,MinMarks,MaxMarks from Grade;
	RETURN